This is a Matlab implementation of the fast exact (anisotropic) TV minimization algorithm
by Chambolle and Darbon.
It has been tested under Linux/Unix/MACOSX/Windows(CygWin).

To compile:

./configure
make

Antonin Chambolle
Jérôme Darbon
Jalal Fadili

